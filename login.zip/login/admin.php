<?php
session_start()
echo "Welcome" . $_SESSION['User'];
?>