<?php
	$con =mysql_connect('localhost','root','root','PORTFOLIO');
	
	if (!$con) {
		die('Please check your connection'.myqli_error($con));
	}
?>