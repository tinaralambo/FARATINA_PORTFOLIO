<?php
session_start();

require_once('bd.php');
	if (isset($_POST['Login']))
	 {
		if (empty($_POST['user']) || empty($_POST['pass'])) {
echo "fill in the blanks";		}
		else {
			$query="SELECT * from users where username='".$_POST['user']."'and password='".$_POST['pass']."'";
			$result=mysqli_query($con,$query);
			if (mysqli_fetch_assoc($result)) {
				$_SESSION['User']=$_POST['user'];
				header('location:admin.php');
			}
			else{
				header("location:index.php?Invalid= Not Correct");
			}
		}
	}
	else {
		echo "It's not working";
	}
?>