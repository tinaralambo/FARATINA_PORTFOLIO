<?php
$servername = "localhost:3306";
$username = "tina"; // database username, default Username for MySQL database is root
$password = "faratin"; //database password, default password for mysql is null
$dbname = 'PORTFOLIO'; //Database name
$u =$_POST['username'];
$e =$_POST['email'];
$o =$_POST['object'];
$m =$_POST['message'];
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "INSERT INTO contact (username, email, object, message) VALUES ('$u', '$e', '$o', '$m')";
if ($conn->query($sql) === TRUE) {
    echo "Bien reçu !";
    header( "refresh:3; url= http://www.faratina-alwaysdata.net/contact.html" ); //this line used to redirect to the index.php page after 3 seconds
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
